
<link href="css/Price-style.css" rel="stylesheet" type="text/css" media="all" />

<!-- <script src="js/jquery.magnific-popup.js" type="text/javascript"></script> -->
	<!-- <script>
		$(document).ready(function() {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});
		});
	</script>
 -->


<div class="main">
	<div class="padding-w3l">
		<div class="content">
			<div class="grid1">
				<div class="header">
					<h3>Paket Mikro</h3>
				</div>
				<div class="info-agile">
					<p> • Desain Responsif 1 Halaman</p>
					<p> • Integrasi Media Sosial</p>
					<p> • Formulir Kontak</p>
					<p> • Hostin Basis WEB</p>
				</div>
				<div class="submit">
					<a class=" sign-up popup-with-zoom-anim"  data-toggle="modal" data-target="#myModal1">Order</a>
				</div>
			</div>
			
			
			<div class="grid2">
				<div class="header">
					<h3>Paket kecil</h3>
				</div>
				<div class="info-agile">
					<p> • Desain Responsif 5 Halaman</p>
					<p> • Galeri Gambar</p>
					<p> • Hosting Standar</p>
					<p> • Formulir Kontak dan pemesanan Website</p>
					
	            </div>
				<div class="submit">
					<a class=" sign-up popup-with-zoom-anim"  data-toggle="modal" data-target="#myModal1">Order</a>
				</div>
			</div>
			
			<div class="grid3">
				<div class="header">
					<h3>Paket Pro</h3>
				</div>
				<div class="info-agile">
					<p> • Desain Responsif 10 Halaman</p>
					<p> • Hosting Premium</p>
					<p> • Keamanan Situs Web</p>
					<p> •  Analisis Situs Web</p>
				</div>
				<div class="submit">
					<a class=" sign-up popup-with-zoom-anim"  data-toggle="modal" data-target="#myModal1">Order</a>
				</div>
			</div>

			
		
		  <div class="clear"> </div>
		</div>
		
		

		
	</div>
</div>
