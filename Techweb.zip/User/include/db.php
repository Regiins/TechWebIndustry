<?php 
$db=new MYSQLi("Localhost","root","","db.tech");
    if($db->connect_error>0){
		die('Connection error');
	}else
	{
		echo'';
	} ;
?>