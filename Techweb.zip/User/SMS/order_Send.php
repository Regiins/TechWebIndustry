 <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'success',
                        'message'   :   'Order Successful Complete!',
                        'position'  :   'right'
                    });
                });
                
    </script>
    