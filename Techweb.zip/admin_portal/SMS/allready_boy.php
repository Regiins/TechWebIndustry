 <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'error',
                        'message'   :   'Allready boy exit !',
                        'position'  :   'right'
                    });
                });
                
    </script>
    