<?php 

$db=new MYSQLi("localhost","root","","db.tech");
    if($db->connect_error>0){
		die('Connection error');
	}else
	{
		echo'';
	} ;
?>